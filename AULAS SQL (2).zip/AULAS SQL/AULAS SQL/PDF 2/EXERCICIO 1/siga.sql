create database siga;
use siga;

-- Aluno
CREATE TABLE Aluno (
    matricula INT PRIMARY KEY,
    cpf CHAR(11) NOT NULL UNIQUE,
    nome_completo VARCHAR(100) NOT NULL,
    data_nascimento DATE,
    email VARCHAR(100),
    telefone VARCHAR(20),
    data_ingresso DATE
);

-- Professor
CREATE TABLE Professor (
    id_professor INT PRIMARY KEY,
    cpf CHAR(11) NOT NULL UNIQUE,
    nome_completo VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    titulacao VARCHAR(50)
);

-- Curso
CREATE TABLE Curso (
    id_curso INT PRIMARY KEY,
    nome_curso VARCHAR(100) NOT NULL,
    duracao_semestres INT,
    id_professor_coordenador INT,
    FOREIGN KEY (id_professor_coordenador) REFERENCES Professor(id_professor)
);

-- Disciplina
CREATE TABLE Disciplina (
    cod_disciplina INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    carga_horaria INT,
    ementa TEXT
);

-- Curso_Disciplina (Relacionamento N:N)
CREATE TABLE Curso_Disciplina (
    id_curso INT,
    cod_disciplina INT,
    PRIMARY KEY (id_curso, cod_disciplina),
    FOREIGN KEY (id_curso) REFERENCES Curso(id_curso),
    FOREIGN KEY (cod_disciplina) REFERENCES Disciplina(cod_disciplina)
);

-- Turma
CREATE TABLE Turma (
    id_turma INT PRIMARY KEY,
    cod_disciplina INT,
    id_professor INT,
    ano INT,
    semestre INT,
    horario VARCHAR(50),
    sala VARCHAR(20),
    FOREIGN KEY (cod_disciplina) REFERENCES Disciplina(cod_disciplina),
    FOREIGN KEY (id_professor) REFERENCES Professor(id_professor)
);

-- Matricula_Turma (Relacionamento N:N com atributos)
CREATE TABLE Matricula_Turma (
    matricula_aluno INT,
    id_turma INT,
    nota_final DECIMAL(5,2),
    frequencia DECIMAL(5,2),
    PRIMARY KEY (matricula_aluno, id_turma),
    FOREIGN KEY (matricula_aluno) REFERENCES Aluno(matricula),
    FOREIGN KEY (id_turma) REFERENCES Turma(id_turma)
);
