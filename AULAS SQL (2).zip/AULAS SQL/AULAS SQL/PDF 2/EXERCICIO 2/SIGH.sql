create database SIGH;
use SIGH;

CREATE TABLE Departamento (
    CodigoDepartamento INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(100) NOT NULL
);

CREATE TABLE Medico (
    CodigoMedico INT PRIMARY KEY AUTO_INCREMENT,
    CRM VARCHAR(20) UNIQUE NOT NULL,
    NomeCompleto VARCHAR(100) NOT NULL,
    Especialidade VARCHAR(100),
    CodigoDepartamento INT,
    FOREIGN KEY (CodigoDepartamento) REFERENCES Departamento(CodigoDepartamento)
);

CREATE TABLE Paciente (
    CodigoPaciente INT PRIMARY KEY AUTO_INCREMENT,
    CPF VARCHAR(14) UNIQUE NOT NULL,
    NomeCompleto VARCHAR(100) NOT NULL,
    DataNascimento DATE NOT NULL,
    Endereco VARCHAR(255),
    Telefone VARCHAR(20),
    TipoConvenio VARCHAR(50)
);

CREATE TABLE Consulta (
    CodigoConsulta INT PRIMARY KEY AUTO_INCREMENT,
    CodigoPaciente INT,
    CodigoMedico INT,
    DataHora DATETIME,
    Sala VARCHAR(20),
    Status ENUM('Agendada', 'Realizada', 'Cancelada'),
    FOREIGN KEY (CodigoPaciente) REFERENCES Paciente(CodigoPaciente),
    FOREIGN KEY (CodigoMedico) REFERENCES Medico(CodigoMedico)
);

CREATE TABLE Internacao (
    CodigoInternacao INT PRIMARY KEY AUTO_INCREMENT,
    CodigoPaciente INT,
    CodigoMedico INT,
    Quarto VARCHAR(20),
    DataEntrada DATE,
    DataAlta DATE,
    Diagnostico TEXT,
    FOREIGN KEY (CodigoPaciente) REFERENCES Paciente(CodigoPaciente),
    FOREIGN KEY (CodigoMedico) REFERENCES Medico(CodigoMedico)
);

CREATE TABLE Prontuario (
    CodigoProntuario INT PRIMARY KEY AUTO_INCREMENT,
    CodigoPaciente INT,
    DataHora DATETIME,
    Descricao TEXT,
    FOREIGN KEY (CodigoPaciente) REFERENCES Paciente(CodigoPaciente)
);

