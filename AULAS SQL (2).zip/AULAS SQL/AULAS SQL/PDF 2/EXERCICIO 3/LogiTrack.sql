create database LogiTrack;
use LogiTrack;

CREATE TABLE Cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  cpf_cnpj VARCHAR(20) NOT NULL UNIQUE,
  nome VARCHAR(100) NOT NULL,
  endereco VARCHAR(255),
  email VARCHAR(100)
);

CREATE TABLE Motorista (
  id_motorista INT AUTO_INCREMENT PRIMARY KEY,
  cpf VARCHAR(14) NOT NULL UNIQUE,
  nome VARCHAR(100) NOT NULL,
  cnh VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE Veiculo (
  placa VARCHAR(10) PRIMARY KEY,
  modelo VARCHAR(50),
  capacidade_carga DECIMAL(10,2)
);

CREATE TABLE Envio (
  codigo_rastreamento VARCHAR(30) PRIMARY KEY,
  endereco_coleta VARCHAR(255),
  endereco_entrega VARCHAR(255),
  data_solicitacao DATE,
  status ENUM('Aguardando Coleta', 'Em Trânsito', 'Entregue'),
  id_remetente INT,
  id_destinatario INT,
  FOREIGN KEY (id_remetente) REFERENCES Cliente(id_cliente),
  FOREIGN KEY (id_destinatario) REFERENCES Cliente(id_cliente)
);

CREATE TABLE Pacote (
  id_pacote INT AUTO_INCREMENT PRIMARY KEY,
  peso DECIMAL(10,2),
  dimensoes VARCHAR(50),
  descricao VARCHAR(255),
  codigo_rastreamento VARCHAR(30),
  FOREIGN KEY (codigo_rastreamento) REFERENCES Envio(codigo_rastreamento)
);

CREATE TABLE RotaEntrega (
  id_rota INT AUTO_INCREMENT PRIMARY KEY,
  id_motorista INT,
  placa_veiculo VARCHAR(10),
  data_saida DATE,
  data_chegada DATE,
  FOREIGN KEY (id_motorista) REFERENCES Motorista(id_motorista),
  FOREIGN KEY (placa_veiculo) REFERENCES Veiculo(placa)
);

CREATE TABLE RotaEnvio (
  id_rota INT,
  codigo_rastreamento VARCHAR(30),
  PRIMARY KEY (id_rota, codigo_rastreamento),
  FOREIGN KEY (id_rota) REFERENCES RotaEntrega(id_rota),
  FOREIGN KEY (codigo_rastreamento) REFERENCES Envio(codigo_rastreamento)
);

CREATE TABLE StatusRastreamento (
  id_status INT AUTO_INCREMENT PRIMARY KEY,
  codigo_rastreamento VARCHAR(30),
  data DATE,
  hora TIME,
  localizacao VARCHAR(100),
  descricao TEXT,
  FOREIGN KEY (codigo_rastreamento) REFERENCES Envio(codigo_rastreamento)
);
