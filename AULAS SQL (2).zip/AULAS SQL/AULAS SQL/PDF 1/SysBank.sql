create database SysBank;
use SysBank;

CREATE TABLE Agencia (
    NumeroAgencia INT PRIMARY KEY,
    Nome VARCHAR(100),
Endereco VARCHAR(255)
);

-- 2. Funcionário
CREATE TABLE Funcionario (
    IDFuncionario INT PRIMARY KEY AUTO_INCREMENT,
    CPF VARCHAR(14) UNIQUE NOT NULL,
    NomeCompleto VARCHAR(100),
    Cargo VARCHAR(50),
    NumeroAgencia INT,
    FOREIGN KEY (NumeroAgencia) REFERENCES Agencia(NumeroAgencia)
);

-- 3. Cliente
CREATE TABLE Cliente (
    IDCliente INT PRIMARY KEY AUTO_INCREMENT,
    CPF VARCHAR(14) UNIQUE NOT NULL,
    NomeCompleto VARCHAR(100),
    DataNascimento DATE,
    Endereco VARCHAR(255),
    Email VARCHAR(100),
    Telefone VARCHAR(20)
);

-- 4. Conta
CREATE TABLE Conta (
    NumeroConta INT PRIMARY KEY,
    Tipo ENUM('Corrente', 'Poupança'),
    SaldoAtual DECIMAL(15,2),
    DataAbertura DATE,
    Status ENUM('Ativa', 'Inativa', 'Bloqueada'),
    IDCliente INT,
    NumeroAgencia INT,
    IDFuncionario INT,
    FOREIGN KEY (IDCliente) REFERENCES Cliente(IDCliente),
    FOREIGN KEY (NumeroAgencia) REFERENCES Agencia(NumeroAgencia),
    FOREIGN KEY (IDFuncionario) REFERENCES Funcionario(IDFuncionario)
);

-- 5. Cartão
CREATE TABLE Cartao (
    NumeroCartao BIGINT PRIMARY KEY,
    NumeroConta INT,
    Tipo ENUM('Débito', 'Crédito'),
    DataValidade DATE,
    Limite DECIMAL(10,2),
    Status ENUM('Ativo', 'Bloqueado'),
    FOREIGN KEY (NumeroConta) REFERENCES Conta(NumeroConta)
);

-- 6. Fatura
CREATE TABLE Fatura (
    IDFatura INT PRIMARY KEY AUTO_INCREMENT,
    NumeroCartao BIGINT,
    DataVencimento DATE,
    ValorTotal DECIMAL(10,2),
    Status ENUM('Aberta', 'Paga', 'Vencida'),
    FOREIGN KEY (NumeroCartao) REFERENCES Cartao(NumeroCartao)
);

-- 7. Transação
CREATE TABLE Transacao (
    IDTransacao INT PRIMARY KEY AUTO_INCREMENT,
    ContaOrigem INT,
    ContaDestino INT,
    Tipo ENUM('Depósito', 'Saque', 'Transferência', 'Pagamento'),
    Valor DECIMAL(15,2),
    DataHora DATETIME,
    FOREIGN KEY (ContaOrigem) REFERENCES Conta(NumeroConta),
    FOREIGN KEY (ContaDestino) REFERENCES Conta(NumeroConta)
);

-- 8. Beneficiário
CREATE TABLE Beneficiario (
    IDBeneficiario INT PRIMARY KEY AUTO_INCREMENT,
    IDCliente INT,
    NomeFavorecido VARCHAR(100),
    CPFCNPJ VARCHAR(20),
    Banco VARCHAR(50),
    Agencia VARCHAR(20),
    Conta VARCHAR(20),
    FOREIGN KEY (IDCliente) REFERENCES Cliente(IDCliente)
);

-- 9. Empréstimo
CREATE TABLE Emprestimo (
    IDEmprestimo INT PRIMARY KEY AUTO_INCREMENT,
    IDCliente INT,
    ValorTotal DECIMAL(15,2),
    TaxaJuros DECIMAL(5,2),
    NumeroParcelas INT,
    DataSolicitacao DATE,
    Status ENUM('Em análise', 'Aprovado', 'Quitado'),
    FOREIGN KEY (IDCliente) REFERENCES Cliente(IDCliente)
);

-- 10. Parcelas
CREATE TABLE Parcela (
    IDEmprestimo INT,
    NumeroParcela INT,
    Valor DECIMAL(10,2),
    DataVencimento DATE,
    DataPagamento DATE,
    PRIMARY KEY (IDEmprestimo, NumeroParcela),
    FOREIGN KEY (IDEmprestimo) REFERENCES Emprestimo(IDEmprestimo)
);

-- 11. Investimentoconsulta
CREATE TABLE Investimento (
    IDInvestimento INT PRIMARY KEY AUTO_INCREMENT,
    IDCliente INT,
    TipoProduto VARCHAR(50),
    ValorAplicado DECIMAL(15,2),
    DataAplicacao DATE,
    Rentabilidade DECIMAL(5,2),
    FOREIGN KEY (IDCliente) REFERENCES Cliente(IDCliente)
);
